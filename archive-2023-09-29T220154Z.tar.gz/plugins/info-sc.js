let handler = async (m, { conn }) => {
let sewa = `
*❏––––––『 𝐒𝐂𝐑𝐈𝐏𝐓 𝐁𝐎𝐓 』––––––❏*

Mau Scriptnya? 
Ada Di YouTube, Tidak Untuk Di Jual Belkan!!! Sc Ini Gratis.\nhttps://youtu.be/xmArxs98ob4\nKebutuhan Bot WhatsApp\nhttps://instagram.com/agatzdev.js\n⚠️Jika Ada Yang Menjual Hub Pembuat http://wa.me/6285811523745

⌕ ❙❘❙❙❘❙❚❙❘❙❙❚❙❘❙❘❙❚❙❘❙❙❚❙❘❙❙❘❙❚❙❘ ⌕
`
conn.reply(m.chat, sewa, m)
}
handler.help = ['dlcdlzmfcl']
handler.tags = ['']
handler.command = /^(scmdkzmclzsmc|scrild;mcldptklndcdlkmncvkcndz)$/i

export default handler