let handler = async (m, { conn }) => {
let fotonya = 'https://i.pinimg.com/originals/10/59/14/105914063b87ce4d1b2227fc822883d5.jpg'
let sewa = `
╔━━━『 *NSWF Menu* 』
┃ ⬡ .hollolewd
┃ ⬡ .sideoppai
┃ ⬡ .animefeets
┃ ⬡ .animebooty
┃ ⬡ .animethighss
┃ ⬡ .animearmpits
┃ ⬡ .lewdanimegirls
┃ ⬡ .biganimetiddies
┃ ⬡ .animeblowjob
┃ ⬡ .gangbang
┃ ⬡ .hinata
┃ ⬡ .lewd
┃ ⬡ .masturbation
┃ ⬡ .ometv
┃ ⬡ .orgy
┃ ⬡ .paptt
╚━━━━━━━━━━━━✧
 _2023 © Tsukasa-BOT_
`
conn.reply(m.chat, sewa, m)
}
handler.help = ['nsfwmenu']
handler.tags = ['main']
handler.command = /^(nsfwmenu)$/i

export default handler